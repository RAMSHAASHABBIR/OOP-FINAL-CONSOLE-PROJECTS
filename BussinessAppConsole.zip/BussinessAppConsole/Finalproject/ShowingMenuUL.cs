﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
     class ShowingMenuUL
    {
        public static string Menu(string option)
        {
            Console.WriteLine("INSTRUCTIONS : DONT USE SPECIAL CHARACTERS AND YOUR PASSWORD LENGTH SHOULD BE UP TO 4 DIGITS");
            Console.WriteLine("1. SIGNIN");
            Console.WriteLine("2. SIGNUP");
            Console.WriteLine("ENTER OPTION");
            option = Console.ReadLine();
            return option;
        }
       public static void showAdminMainMenu()
        {

            Console.WriteLine("Select one of the option from 1 to 8");
            Console.WriteLine("  1.ADD DRINK");
            Console.WriteLine("  2.ADD FOOD");
            Console.WriteLine("  3.VIEW DRINK PRODUCTS");
            Console.WriteLine("  4.VIEW FOOD PRODUCTS");
            Console.WriteLine("  5.UPDATE PRODUCT");
            Console.WriteLine("  6.DELETING PRODUCT");
            Console.WriteLine("  7.PRODUCT TO BE ORDERED SOON");
            Console.WriteLine("  8.ADDING NEW STOCK");
            Console.WriteLine("  8.PRESS 10 TO GO TO EXIT");
        }
        public static void showUserMainMenu() 
        {

            Console.WriteLine("Select one of the option from 1 to 8");
            Console.WriteLine("  1.VIEW DRINK PRODUCTS");
            Console.WriteLine("  2.VIEW FOOD PRODUCTS");
            Console.WriteLine("  3.PRODUCT WITH HIGHEST PRICE");
            Console.WriteLine("  4.VIEWING PRODUCTS WITH TAX");
            Console.WriteLine("  5.ENTER THE FOOD YOU WANT TO ORDER");
            Console.WriteLine("  6.VIEW THE TOTAL BILL");
            Console.WriteLine("  7.SHOWING ALL YOUR ORDERS");
            Console.WriteLine("  8.PRESS 7 TO GO TO EXIT");
        }
    }
}
