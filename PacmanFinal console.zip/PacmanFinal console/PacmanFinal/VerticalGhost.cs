﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
     class VerticalGhost : Ghost
    {
        public  GameDirection direction = GameDirection.UP;
        public VerticalGhost(char Character, GameCell c) : base(Character, c)
        {
            CurrentCell = c;
            DisplayCharacter = Character;
        }
        public override void Move()
        {
            GameCell nextCell = CurrentCell.nextCell(this.direction);
            if (nextCell != null)
            {
                GameObject newGO = new GameObject(' ', GameObjectType.NONE);
                GameCell currentCell = CurrentCell;
                Program.clearGameCellContent(currentCell, newGO);
                CurrentCell = nextCell;
                Program.printGameObject(this);
            }
            else if(nextCell == null && this.direction == GameDirection.UP)
            {
                this.direction = GameDirection.DOWN;
            }
            else if (nextCell == null && this.direction == GameDirection.DOWN)
            {
                this.direction = GameDirection.UP;
            }
        }
    }
} 
