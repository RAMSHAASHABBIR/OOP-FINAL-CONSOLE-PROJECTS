﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
    internal class OrdersDL
    {
        public static List<Orders> orders = new List<Orders>();
        public void add(Orders o)
        { orders.Add(o); }

        public List<string> checkUserInLists(string username)
        {
            for(int i =0; i< orders.Count;i++)
            {
                if (orders[i].orders[0]==username)
                {
                    return orders[i].orders;
                }
            }
            return null;
        }
    }
}
