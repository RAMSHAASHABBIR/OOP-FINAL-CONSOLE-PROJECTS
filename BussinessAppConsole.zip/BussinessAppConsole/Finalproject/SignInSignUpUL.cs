﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Finalproject
{
    class SignInSignUpUL
    {
        public static SignInSignUp takeInputWithoutRole()
        {
            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                SignInSignUp user = new SignInSignUp(name, password);
                return user;
            }
            return null;

        }
        public static SignInSignUp takeInputWithRole()
        {
            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter Role: ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                SignInSignUp user = new SignInSignUp(name, password, role);
                return user;
            }
            return null;

        }
        public static void Invalidinputshown()
        {
            Console.WriteLine("Invalid User ");
        }

    }

}
