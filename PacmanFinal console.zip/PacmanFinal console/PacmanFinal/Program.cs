﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EZInput;
using PacmanFinal;

namespace PacmanFinal
{
    class Program
    {
        static void Main(string[] args)
        {
            GameGrid grid = new GameGrid("E:\\PacmanGame\\PacmanGame\\maze.txt", 24, 71);
            GameCell start = new GameCell(12, 22, grid );
            PacmanPlayer pacman = new PacmanPlayer('p', start);
            GameCell startGhost = new GameCell(19,25,grid);
            RandomGhost randomGhost = new RandomGhost('G',startGhost);
            GameCell startGhost1 = new GameCell(20,57,grid);
            VerticalGhost verticalGhost = new VerticalGhost('G', startGhost1);
            GameCell startGhost2 = new GameCell(15, 39, grid);
            HorizontalGhost horizontalGhost = new HorizontalGhost('G', startGhost2);
            GameCell startGhost3 = new GameCell(21,30,grid);
            SmartGhost smartGhost = new SmartGhost('G',startGhost3);

            printMaze(grid);
            printGameObject(pacman);


            bool gameRunning = true;
            while (gameRunning)
            {
                randomGhost.Move();
                verticalGhost.Move();
                horizontalGhost.Move();
                smartGhost.Move();
               
                Thread.Sleep(90);
                if (Keyboard.IsKeyPressed(Key.UpArrow))
                {
                    moveGameObject(pacman, GameDirection.UP);
                }

                if (Keyboard.IsKeyPressed(Key.DownArrow))
                {
                    moveGameObject(pacman, GameDirection.DOWN);
                }

                if (Keyboard.IsKeyPressed(Key.RightArrow))
                {
                    moveGameObject(pacman, GameDirection.RIGHT);
                }

                if (Keyboard.IsKeyPressed(Key.LeftArrow))
                {
                    moveGameObject(pacman, GameDirection.LEFT);
                }
               
            }
            
        }
        public static void clearGameCellContent(GameCell gameCell, GameObject newGameObject)
        {
            gameCell.currentGameObject = newGameObject;
            Console.SetCursorPosition(gameCell.Y, gameCell.X);
            Console.Write(newGameObject.DisplayCharacter);

        }
        public static void printGameObject(GameObject gameObject)
        {
            Console.SetCursorPosition(gameObject.CurrentCell.Y, gameObject.CurrentCell.X);
            Console.Write(gameObject.DisplayCharacter);

        }

       public static void moveGameObject(GameObject gameObject, GameDirection direction)
        {
            GameCell nextCell = gameObject.CurrentCell.nextCell(direction);
            if (nextCell != null)
            {
                GameObject newGO = new GameObject(' ',GameObjectType.NONE);
                GameCell currentCell = gameObject.CurrentCell;
                clearGameCellContent(currentCell, newGO);
                gameObject.CurrentCell = nextCell;
                printGameObject(gameObject);
            }
        }

        static void printMaze(GameGrid grid)
        {
            for (int x = 0; x < grid.rows; x++)
            {
                for (int y = 0; y < grid.cols; y++)
                {
                    GameCell cell = grid.getCell(x, y);
                    printCell(cell);
                }

            }
        }

        public static void printCell(GameCell cell)
        {
            Console.SetCursorPosition(cell.Y, cell.X);
            Console.Write(cell.currentGameObject.DisplayCharacter);
        }

    }
}
