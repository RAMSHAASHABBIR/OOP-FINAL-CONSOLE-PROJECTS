﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
    class RandomGhost : Ghost
    {
        public static GameDirection direction = GameDirection.UP;
        public RandomGhost(char Character, GameCell c) : base(Character, c)
        {
            CurrentCell = c;
            DisplayCharacter = Character;
        }
        public int ghostDirection()  
        {
            Random r = new Random();
            int value = r.Next(4);
            return value;
        }
        public override void Move()
        {
            int value = ghostDirection();
            if (value == 0)
            {
                direction = GameDirection.DOWN;
                Program.moveGameObject(this, GameDirection.DOWN);
            }
            else if (value == 1)
            {
                direction = GameDirection.UP;
                Program.moveGameObject(this,GameDirection.UP);
            }
            else if (value == 2)
            {
                direction = GameDirection.RIGHT;
                Program.moveGameObject(this, GameDirection.RIGHT);
            }
            else if (value == 3)
            {
                direction= GameDirection.LEFT;
                Program.moveGameObject(this, GameDirection.LEFT);
            }
           
        }
    }
 }
