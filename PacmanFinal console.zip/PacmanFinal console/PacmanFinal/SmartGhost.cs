﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
    class SmartGhost : Ghost
    {
        public SmartGhost(char Character, GameCell c) : base(Character, c)
        {
            CurrentCell = c;
            DisplayCharacter = Character;
        }
        public override void Move()
        {
            int X = CurrentCell.X;
            int Y = CurrentCell.Y;
            int pX = 12;
            int pY = 22;
            double[] distance = new double[4] { 1000000, 1000000, 1000000, 1000000 };
            if (CurrentCell.gameGrid.GameCells[X, Y - 1].currentGameObject.DisplayCharacter != '|' && CurrentCell.gameGrid.GameCells[X, Y - 1].currentGameObject.DisplayCharacter != '%')
            {
                int y = Y - 1;
                distance[0] = (calculateDistance(ref X, ref y, pX, pY));
            }
            if (CurrentCell.gameGrid.GameCells[X, Y + 1].currentGameObject.DisplayCharacter != '|' && CurrentCell.gameGrid.GameCells[X, Y + 1].currentGameObject.DisplayCharacter != '%')
            {
                int y = Y + 1;
                distance[1] = (calculateDistance(ref X, ref y, pX, pY));
            }
            if (CurrentCell.gameGrid.GameCells[X + 1, Y].currentGameObject.DisplayCharacter != '|' && CurrentCell.gameGrid.GameCells[X + 1, Y].currentGameObject.DisplayCharacter != '%' && CurrentCell.gameGrid.GameCells[X + 1, Y].currentGameObject.DisplayCharacter != '#')
            {
                int x = X + 1;
                distance[2] = (calculateDistance(ref x, ref Y, pX, pY));
            }
            if (CurrentCell.gameGrid.GameCells[X - 1, Y].currentGameObject.DisplayCharacter != '|' && CurrentCell.gameGrid.GameCells[X - 1, Y].currentGameObject.DisplayCharacter != '%' && CurrentCell.gameGrid.GameCells[X - 1, Y].currentGameObject.DisplayCharacter != '#')
            {
                int x = X + 1;
                distance[3] = (calculateDistance(ref x ,ref Y, pX, pY));
            }
            if (distance[0] <= distance[1] && distance[0] <= distance[2] && distance[0] <= distance[3])
            {
              
                Program.moveGameObject(this, GameDirection.LEFT);
            }
            if (distance[1] <= distance[0] && distance[1] <= distance[2] && distance[1] <= distance[3])
            {
               
                Program.moveGameObject(this, GameDirection.RIGHT);
            }
            if (distance[2] <= distance[0] && distance[2] <= distance[1] && distance[2] <= distance[3])
            {
               
                Program.moveGameObject(this, GameDirection.DOWN);
               
            }
            else
            {
               
                Program.moveGameObject(this, GameDirection.UP);
              
            }
        }
        public double calculateDistance(ref int X, ref int Y, int pX, int pY)
        {
            return Math.Sqrt(Math.Pow((pX - X), 2) + Math.Pow((pY - Y), 2));
        }
    }
}
