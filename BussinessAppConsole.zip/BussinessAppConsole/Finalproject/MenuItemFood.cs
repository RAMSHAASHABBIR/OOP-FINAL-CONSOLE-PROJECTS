﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
    class MenuItemFood : MenuItem
    {
        private string Productcatagoryfood;
        public MenuItemFood(string Productcatagoryfood, string Productname, string Price, string Stockquantity) : base(Productname, Price, Stockquantity)
        {
            this.Productcatagoryfood = Productcatagoryfood;
        }
        public string getfood()
        {
            return Productcatagoryfood;
        }
        public override string getType()
        {
            return Productcatagoryfood;
        }
        public override string toString()
        {

            string s = base.toString() + "  " + "product catagory: " + Productcatagoryfood;
            return s;
        }
    }
}
