﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
     class PacmanPlayer :GameObject
    {
        public PacmanPlayer(char Character, GameCell c) :base(Character ,GameObjectType.PLAYER)
        {
            CurrentCell = c;
            DisplayCharacter = Character;
        }
        public GameCell move(GameDirection direction)
         {
            return this.CurrentCell.nextCell(direction);
                
         }
    }
}
