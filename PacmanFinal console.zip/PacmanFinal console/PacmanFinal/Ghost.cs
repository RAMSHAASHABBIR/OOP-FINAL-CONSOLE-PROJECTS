﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
    abstract class Ghost : GameObject
    {
        public abstract void Move();
        public Ghost(char Character, GameCell c) : base(Character, GameObjectType.PLAYER)
        {
            CurrentCell = c;
            DisplayCharacter = Character;
        }
         
    }
}
