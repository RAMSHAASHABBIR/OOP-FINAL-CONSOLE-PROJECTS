﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
    class MenuItemDrink : MenuItem
    {
        private string Productcatagorydrink;
        public MenuItemDrink(string Productcatagorydrink, string Productname, string Price, string Stockquantity) : base(Productname, Price, Stockquantity)
        {
            this.Productcatagorydrink = Productcatagorydrink;
        }
        public override string toString()
        {
            string s = base.toString() + "  " + "product catagory: " + Productcatagorydrink;
            return s;
        }

        public override string getType()
        {
            return Productcatagorydrink;
        }
    }
} 
      