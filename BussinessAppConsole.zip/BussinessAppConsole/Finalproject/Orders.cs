﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
    class Orders
    {
        public List<string> orders = new List<string>();
        public Orders(string username)
        {
            orders.Add(username);
        }
        public void Addingorder(string name)
        {
            orders.Add(name);
        }
        public void Showorders() 
        { 
            Console.WriteLine("ORDERS ARE :");
            for (int i = 1; i < orders.Count; i++)
            {
                Console.WriteLine(orders[i]);
            }
        }
    }
}
