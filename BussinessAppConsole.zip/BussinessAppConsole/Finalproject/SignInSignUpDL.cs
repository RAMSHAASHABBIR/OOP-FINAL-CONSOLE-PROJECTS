﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Finalproject
{
     class SignInSignUpDL
     {
        public static List<SignInSignUp> users = new List<SignInSignUp>();
        public static SignInSignUp signIn(SignInSignUp user)
        {
            foreach (SignInSignUp storedUser in users)
            {
                if (user.getName() == storedUser.getName() && user.getPassword() == storedUser.getPassword())
                {
                    return storedUser;
                }
            }
            return null;
        }
        public static void storeDataInList( SignInSignUp user)
        {
            users.Add(user);
        }
       
       public static void storeDataInFile(string path1, SignInSignUp userq)
        {
            StreamWriter file = new StreamWriter(path1);

            for (int i = 0; i < users.Count; i++) 
            {
                file.WriteLine(users[i].getName()+ "," + users[i].getPassword() + "," + users[i].getRole());
            }
            file.Flush();
            file.Close();

        }
        public static bool readData(string path1)

        {
            if (File.Exists(path1))
            {
                StreamReader file = new StreamReader(path1);
                string record;
                while ((record = file.ReadLine()) != null)
                {

                    string name = parseData1(record, 1);
                    string password = parseData1(record, 2);
                    string role = parseData1(record, 3);
                    SignInSignUp user = new SignInSignUp(name, password, role);
                    storeDataInList(user); 
                }
                file.Close();
                return true;
            }
            return false; 
        }
        public static string parseData1(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        public static bool ValidCustomerName(SignInSignUp userq)
        {
            bool ispresent = true;
            for(int i =0 ; i < users.Count;i++)
            {
                if(users[i].getName() == userq.getName())
                {
                    ispresent = false;
                    break;
                }
            }
            return ispresent;
        }
    }
}
