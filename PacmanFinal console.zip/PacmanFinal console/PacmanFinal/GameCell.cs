﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
    class GameCell
    {
        public int X;
        public int Y;
        public GameObject currentGameObject;
        public GameGrid gameGrid;
        public GameCell(int x, int y, GameGrid gameGrid)
        {
            this.X = x;
            this.Y = y;
            this.gameGrid = gameGrid ;
        }
        public GameCell nextCell(GameDirection direction)
        {
            if(direction==GameDirection.UP)
            {
                GameCell next = gameGrid.GameCells[X - 1, Y];
                if (next != null && next.currentGameObject.Type != GameObjectType.WALL)
                    return next;
                else return null;
            }
            if (direction==GameDirection.DOWN)
            {
                GameCell next = gameGrid.GameCells[X + 1, Y];
                if (next != null && next.currentGameObject.Type != GameObjectType.WALL)
                return next;
                else return null;

            }
            if (direction==GameDirection.RIGHT)
            {
                GameCell next = gameGrid.GameCells[X, Y+1];
                if (next != null && next.currentGameObject.Type != GameObjectType.WALL)
                    return next;
                else
                    return null;
               
            }
            if (direction==GameDirection.LEFT)
            {
                GameCell next = gameGrid.GameCells[X, Y - 1];
                if (next != null && next.currentGameObject.Type != GameObjectType.WALL)
                    return next;
                else
                    return null;
            }
            return gameGrid.GameCells[X, Y];
        }
    }
}
