﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanFinal
{
     class GameObject
    {
        public char DisplayCharacter;
        public GameCell CurrentCell;
        public GameObjectType Type;
        public char previous;
        public GameObject(char DisplayCharacter, GameObjectType Type)
        {
            this.Type = Type;
            this.DisplayCharacter = DisplayCharacter;
        }
        public static GameObjectType GetGameObjectType (char displayCharacter)
        {
            if (displayCharacter == 'P')
                return GameObjectType.PLAYER;
            if(displayCharacter =='G')
                return GameObjectType.ENEMY;
            if (displayCharacter == '%' || displayCharacter == '|' || displayCharacter == '#')
                return GameObjectType.WALL;
            if (displayCharacter == '.')
                return GameObjectType.REWARD;
            else
                return GameObjectType.NONE;
        }
    }
}
