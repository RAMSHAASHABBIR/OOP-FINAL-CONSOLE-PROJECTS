﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Finalproject
{
    internal class Program
    {
        static void Main(string[] args) 
        {
            string path1 = "E:\\Finalproject\\Finalproject\\path1.txt";
            string Pathcrud = "E:\\Finalproject\\Finalproject\\Pathcrud.txt";
            MenuItemUL menuItemUL = new MenuItemUL();
            OrdersDL ordersDL = new OrdersDL();
            string Option = "";
            float Nowtotal = 0, Bill = 0; ;
            string choose = "",select = "";
            string temp = "", temp1 = "", temp2 = "",temp3="",temp4="",temp5="",temp6="",temp7="",temp8="";
            SignInSignUpDL.readData(path1);
            MenuItemDL. readData(Pathcrud);
            do
            {
                Console.Clear();
                Option = ShowingMenuUL.Menu(Option);
                Console.Clear();
                if (Option == "1")
                {
                    SignInSignUp user = SignInSignUpUL.takeInputWithoutRole();
                    if (user != null)
                    {
                        user = SignInSignUpDL.signIn(user);

                        if (user == null)
                        {
                            SignInSignUpUL.Invalidinputshown();
                            continue;
                        }
                        bool check = user.isAdmin();
                        if (check == true)
                        {
                            Console.Clear();
                            do
                            {
                                ShowingMenuUL.showAdminMainMenu();
                                choose = AdminMainMenu();
                                Console.Clear();
                                if (choose == "1")
                                {
                                    MenuItemDrink itemDrink = menuItemUL.TakeinputDrink();
                                    MenuItemDL.AddingDrinktolist(itemDrink);
                                    MenuItemDL.  storeDataInFile(Pathcrud);
                                    Console.Clear();
                                }
                                else if (choose == "2")
                                {
                                    MenuItemFood itemFood = menuItemUL.TakeinputFood();
                                    MenuItemDL.AddingFoodtolist(itemFood);
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                    Console.Clear();
                                }
                                else if (choose == "3")
                                {
                                    menuItemUL.Printdrink();
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choose == "4")
                                {
                                    menuItemUL.Printfood();
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choose == "5")
                                {
                                    string Productname = menuItemUL.WhichProduct();
                                    Console.Clear();
                                    menuItemUL.Updatingproduct(Productname);
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                }
                                else if (choose == "6")
                                {
                                    string Productname = menuItemUL.WhichProduct();
                                    MenuItemDL.Deletingproduct(Productname, menuItemUL);
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                }
                                else if (choose == "7")
                                {
                                    MenuItemDL.threshold(ref temp, ref temp1, ref temp2, menuItemUL);

                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (choose == "8")
                                {
                                    string name = menuItemUL.WhichProduct();
                                    MenuItemDL.AddingStock(name, menuItemUL);
                                    MenuItemDL.storeDataInFile(Pathcrud);
                                }
                            }
                            while (choose != "10");
                        }
                        else if (check == false)
                        {
                            Console.Clear();
                            do
                            {
                                ShowingMenuUL.showUserMainMenu();
                                select = UserMainMenu();
                                if (select == "1")
                                {
                                    Console.Clear();
                                    menuItemUL.Printdrink();
                                    Console.Clear();
                                }
                                else if (select == "2")
                                {
                                    Console.Clear();
                                    menuItemUL.Printfood();
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if (select == "3")
                                {
                                    Console.Clear();
                                    MenuItemDL.HighestPrice(ref temp3, ref temp4, ref temp5);
                                    menuItemUL. PrintHighestPriceProduct(ref temp3,ref temp4,ref temp5);
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                                else if(select == "4")
                                {
                                    Console.Clear();
                                    MenuItemDL.Tax(ref temp6, ref temp7, ref temp8, ref Nowtotal, menuItemUL);
                                    Console.Clear();
                                }
                                else if(select == "5")
                                {
                                    Console.Clear();
                                    string name =  menuItemUL. WhichProduct();
                                    MenuItemDL.Bill( name,ref Bill,menuItemUL,ordersDL);
                                    Console.Clear();
                                }
                                else if(select == "6")
                                {
                                    Console.Clear();
                                    menuItemUL. PrintTotalBill(ref Bill);
                                    Console.Clear();
                                }
                                else if(select == "7")
                                {
                                    Console.Clear();
                                  //  ordersDL.Showorders();
                                    Console.ReadKey();
                                    Console.Clear();
                                }
                            }
                            while (select != "8");
                        }
                    }

                }
                else if (Option == "2")
                {
                    SignInSignUp userq = SignInSignUpUL.takeInputWithRole();
                    bool checkname = SignInSignUpDL.ValidCustomerName(userq);
                    bool checklength = Validations.LengthValidation(userq);
                    bool check = Validations.AsciiValidattion(userq);
                    if (check == true && checklength == true && checkname == true)
                    {
                        if (userq != null)
                        {
                            SignInSignUpDL.storeDataInList(userq);
                            SignInSignUpDL.storeDataInFile(path1, userq);
                            continue;
                        }

                    }
                    else
                    {
                        SignInSignUpUL.Invalidinputshown();
                        Console.ReadKey();
                       
                    }
                }
                else
                {
                    Console.WriteLine("such user not exists");
                    Console.ReadKey();
                }

            }
            while (Option != "3");
        }

        static string AdminMainMenu()
        {
            string chosing = "";
            chosing = Console.ReadLine();
            return chosing;
        }
        static string UserMainMenu()
        {
            string chosing = "";

            chosing = Console.ReadLine();
            return chosing;
        }
    }
}
