﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
     class SignInSignUp 
    {
        private string Name;
        private string Password;
        private string Role;

        public string getName()
        {
            return Name;
        }
        public string getPassword()
        {
            return Password;
        }
        public string getRole()
        {
            return Role;
        }
       
        public SignInSignUp(string name, string password)
        { 
            this.Name = name;
            this.Password = password;
        } 
        public SignInSignUp(string name, string password, string role)
        {
            this.Name = name; 
            this.Password = password;
            this.Role = role; 
        }
        public bool isAdmin()
        {
            if (Role == "admin")
            {
                return true;
            }
            return false;
        } 
    }
}
