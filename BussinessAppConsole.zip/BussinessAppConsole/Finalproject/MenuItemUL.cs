﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Finalproject
{
    class MenuItemUL
    {
        public MenuItemDrink TakeinputDrink()
        {
            Console.WriteLine("Enter product name :");
            string Productname = Console.ReadLine();
            string Productcatagory = "drink";
            Console.WriteLine("Enter product price :");
            string Price = Console.ReadLine();
            Console.WriteLine("Enter product stock quantity :");
            string Stockquantity = Console.ReadLine();
            MenuItemDrink drinks = new MenuItemDrink(Productcatagory, Productname, Price, Stockquantity);
            return drinks;
        }
        public MenuItemFood TakeinputFood()
        {
            Console.WriteLine("Enter product name :");
            string Productname = Console.ReadLine();
            string Productcatagory = "food";
            Console.WriteLine("Enter product price :");
            string Price = Console.ReadLine();
            Console.WriteLine("Enter product stock quantity :");
            string Stockquantity = Console.ReadLine();
            MenuItemFood food = new MenuItemFood(Productcatagory, Productname, Price, Stockquantity);
            return food;
        }
        public void Printfood()
        {
            foreach (MenuItem i in MenuItemDL.products)
            {
                if (i.getType() == "food")
                {
                    Console.WriteLine(i.toString());
                    Console.ReadKey();
                }

            }
        }
        public void Printdrink()
        {
            foreach (MenuItem i in MenuItemDL.products)
            {
                if (i.getType() == "drink")
                {
                    Console.WriteLine(i.toString());
                    Console.ReadKey();
                }

            }
        }
        public void Productexist()
        {
            Console.WriteLine("This product doesnt exist");
            Console.ReadKey();
        }
        public string WhichProduct()
        {
            Console.WriteLine("Enter product name :");
            string Productname = Console.ReadLine();
            return Productname;
        }
        public void Updatingproduct(string Productname)
        {
            bool flag = false;
            foreach (MenuItem i in MenuItemDL.products)
            {
                if (Productname == i.GetName())
                {
                    Console.WriteLine("Enter product name :");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter product price :");
                    string price = Console.ReadLine();
                    i.setName(name);
                    i.setPrice(price);
                    flag = true;
                    break;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("This product doesnt exist");
                Console.Clear();
            }
        }
            public void ProductToOrderSoon(ref string temp,ref string temp1,ref string temp2)
            {
            Console.WriteLine("Product name :  " + temp + "Product price : " + temp1 + "Product stockquantity : " + temp2);
            }
        public string Enterstock()
        {
            Console.WriteLine("Enter product stock quantity :");
            string Stockquantity = Console.ReadLine();
            return Stockquantity;
        }
        public void PrintHighestPriceProduct(ref string temp3,ref string temp4,ref string temp5)
        {
            Console.WriteLine("PRODUCT NAME :{0} PRODUCT PRICE :{1} PRODUCT STOCK :{2}", temp3, temp4, temp5);
        }
        public void PrintProductWithTax(ref string temp6, ref string temp7, ref string temp8,ref float Nowtotal)
        {
            Console.WriteLine("MONEY OF EVERY PRODUCT WITH 10% TAX");
            Console.WriteLine("PRODUCT NAME :{0}  PRODUCT PRICE :{1} PRODUCT STOCK :{2}  NOW TOTAL MONEY :{3}", temp6, temp7, temp8, Nowtotal);
        }
       public void PrintTotalBill(ref float Bill)
        {
            Console.WriteLine("YOUR TOTAL BILL IS :");
            Console.WriteLine(Bill);
            Console.ReadKey();
        }
    }
}

 