﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
    class MenuItem 
    {
        protected string productname;
        protected string price;
        protected string stockquantity;
        public MenuItem( string Productname,string Price,string Stockquantity)
        {
            productname = Productname;
            price = Price;
            stockquantity = Stockquantity; 
        }
        public virtual string getType()
        {
            return "food and drink";
        } 
        public string GetName()
        {
            return productname;
        }
        public string GetStockquantity()
        {
            return stockquantity;
        }
        public string GetPrice()
        {
            return price ;
        }
        
        public void setName(string name)
        {
            this.productname = name; 
        }
        public void setPrice(string price)
        {
            this.price = price;
        }
        public void setStockQuantity(string quantity)
        {
            this.stockquantity = quantity;
        }

        public virtual string toString()
        {
            string s =  "product name: " + productname  + "  " + "product price:" + price + "  " + "stock quantity:" + stockquantity;
            return s;
        }
    }
}  
