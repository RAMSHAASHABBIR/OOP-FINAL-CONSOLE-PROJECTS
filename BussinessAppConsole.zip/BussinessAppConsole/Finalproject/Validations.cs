﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finalproject
{
     class Validations
    {
        public static bool AsciiValidattion(SignInSignUp user)
        {
            // true if no speccial character, false otherwise
            bool specialChar = true;

            for (int i = 0; i < user.getPassword().Length; i++)
            {
                if ((user.getPassword()[i] >= 48 && user.getPassword()[i] <= 57) || (user.getPassword()[i] >= 65 && user.getPassword()[i] <= 90) || (user.getPassword()[i] >= 97 && user.getPassword()[i] <= 122))
                {
                    continue;
                    // return true
                }
                else
                {
                    //special character was found
                    specialChar = false;
                }
            }
            return specialChar;
        }
        public static bool LengthValidation(SignInSignUp user)
        {
            bool length = false;
            if (user.getPassword().Length == 4)
            {
                length = true;
            }
            return length;
        }
    }
}
