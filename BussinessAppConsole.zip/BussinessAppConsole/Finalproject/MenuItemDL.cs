﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Finalproject
{
    class MenuItemDL
    {
        public static List<MenuItem> products = new List<MenuItem>();
        public static void AddingDrinktolist(MenuItemDrink itemDrink)
        {
            products.Add(itemDrink);
            /*bool f = false;
            for (int i = 0; i < products.Count ; i++)
            {
                Console.WriteLine("eer");
               
                if (itemDrink.GetName() == products[i].GetName())
                {
                    f = true;
                } 
                if(f==false)
                {
                    products.Add(itemDrink);
                }
                else
                {
                    Console.WriteLine("already exists");
                    Console.ReadKey(); 
                }
            } */
        }
        public static void AddingFoodtolist(MenuItemFood itemFood)
        {
            products.Add(itemFood);
        }
        public static void Deletingproduct(string Productname, MenuItemUL menuItemUL)
        {
            bool flag = false;
            for (int i = 0; i < products.Count; i++)
            {
                if (Productname == products[i].GetName())
                {
                    products.RemoveAt(i);
                    flag = true;
                }
            }
            if (flag == false)
            {
                menuItemUL.Productexist();
            }
        }
        public static void threshold(ref string temp, ref string temp1, ref string temp2, MenuItemUL menuItemUL)
        {
            for (int j = 0; j < products.Count(); j++)
            {
                if (int.Parse(products[j].GetStockquantity()) < 6)
                {
                    temp = products[j].GetName();
                    temp1 = products[j].GetPrice();
                    temp2 = products[j].GetStockquantity();
                    menuItemUL.ProductToOrderSoon(ref temp, ref temp1, ref temp2);
                }
            }
        }
        public static void AddingStock(string name, MenuItemUL menuItemUL)
        {

            for (int j = 0; j < products.Count(); j++)
            {
                if (name == products[j].GetName())
                {
                    string Stockquantity = menuItemUL.Enterstock();
                    int sum = int.Parse(products[j].GetStockquantity()) + int.Parse(Stockquantity);
                    products[j].setStockQuantity(sum.ToString());
                }
            }

        }
        public static void HighestPrice(ref string temp3, ref string temp4, ref string temp5)
        {
            int i = 0;

            while (i < products.Count())
            {
                for (int j = 0; j < products.Count(); j++)
                {

                    if (int.Parse(products[i].GetPrice()) < int.Parse(products[j].GetPrice()))
                    {
                        temp3 = products[j].GetName();
                        temp4 = products[j].GetPrice();
                        temp5 = products[j].GetStockquantity();

                    }
                }
                i++;
            }
        }
        public static void Tax(ref string temp6, ref string temp7, ref string temp8, ref float Nowtotal, MenuItemUL menuItemUL)
        {
            float tax = 0;
            for (int j = 0; j < products.Count(); j++)
            {

                tax = int.Parse(products[j].GetPrice()) * 10 / 100;
                Nowtotal = int.Parse(products[j].GetPrice()) + tax;
                temp6 = products[j].GetName();
                temp7 = products[j].GetPrice();
                temp8 = products[j].GetStockquantity();
                menuItemUL.PrintProductWithTax(ref temp6, ref temp7, ref temp8, ref Nowtotal);
                Console.ReadKey();
            }
        }
        public static void Bill(string name, ref float Bill, MenuItemUL menuItemUL,OrdersDL ordersDL)
        {
            bool FoundName = false;
            for (int j = 0; j < products.Count(); j++)
            {
                if (name == products[j].GetName())
                {
                    float temp = float.Parse(products[j].GetPrice()) * 10 / 100;
                    Bill = Bill + float.Parse(products[j].GetPrice()) + temp;
                    FoundName = true;
                //    ordersDL.Addingorder(name);
                }
            }
            if (FoundName == false)
            {

                menuItemUL.Productexist();
            } 
        }
        public static void storeDataInFile(string Pathcrud)
        {
            StreamWriter file = new StreamWriter(Pathcrud);

            for (int i = 0; i < products.Count; i++)
            {
                file.WriteLine(products[i].getType()+ "," + products[i].GetName() + "," + products[i].GetPrice() + "," + products[i].GetStockquantity());
            }
            file.Flush();
            file.Close();

        }
        public static bool readData(string Pathcrud)

        {
            if (File.Exists(Pathcrud))
            {
                StreamReader file = new StreamReader(Pathcrud);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                     
                    string catagory = parseData1(record, 1);
                    string name = parseData1(record, 2); 
                    string price = parseData1(record, 3);
                    string stock = parseData1(record, 4);
                    if (catagory == "drink")
                    { 
                        MenuItemDrink drink = new MenuItemDrink(catagory, name, price, stock) ;
                        AddingDrinktolist(drink);
                    }
                    else if(catagory == "food")
                    {
                        MenuItemFood food = new MenuItemFood(catagory, name, price, stock);
                        AddingFoodtolist(food);
                    }
                }
                file.Close(); 
                return true;
            }
            return false;
        }
        public static string parseData1(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
    }
}
